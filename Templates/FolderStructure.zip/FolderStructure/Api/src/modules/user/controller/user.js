

const userHomeController = (req, res) => {
    res.json({ message: 'UserModule' })
}


export {
    userHomeController
}