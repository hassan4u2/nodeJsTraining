

const productHomeController = (req, res) => {
    res.json({ message: 'ProductModule' })
}



export {
    productHomeController
}